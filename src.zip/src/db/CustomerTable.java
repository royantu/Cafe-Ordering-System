package db;

import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;

import system.ordering.cafe.DatabaseConnection;

public class CustomerTable {
	private static final String TABLE_NAME = "customer";
	private DatabaseConnection dbConnect;
	private Statement stmnt;
	
	public int id;
	public String name;
	public String mobileNumber;
	public String tableNumber;
	public long logInTime;
	
	public CustomerTable() {
		dbConnect = new DatabaseConnection();
		try {
			stmnt = dbConnect.getStatement();
		}catch(Exception ex) {
			System.out.println("Error in customer table class: " + ex.toString());
		}
	}
	
	public void addNewCustomer(String name, String mobileNumber,
			String tableNumber) {
		
		String insertQuery = "insert into " + TABLE_NAME + 
				"(name, mobile_number, table_number) values ('" + name
				+"','" + mobileNumber + "','" + tableNumber + "');";
		try {
			System.out.println(insertQuery);
			stmnt.executeUpdate(insertQuery);
			
		}catch(Exception ex) {
			System.out.println("Error while inserting into customer table " + ex.toString());
		}
	}
	
	public CustomerTable getLatesEntry(String mobileNumber) {
		String queryString = "select * from " + TABLE_NAME + 
				" where mobile_number='"+mobileNumber+"' order by log_in_time desc limit 1";
		try {
			return convertToCustomerTable(stmnt.executeQuery(queryString)); 
		}catch(Exception ex) {
			System.out.println("Error while retrivin the latest logged in inforation");
		}
		return new CustomerTable();
	}
	
	private CustomerTable convertToCustomerTable(ResultSet res) {
		if(res==null) {
			return null;
		}
		CustomerTable customer = new CustomerTable();
		try {
			while(res.next()) {
				customer.id = res.getInt("id");
				customer.name = res.getString("name");
				customer.mobileNumber = res.getString("mobile_number");
				customer.tableNumber = res.getString("table_number");
				customer.logInTime = getTimeFromDateTimeString(res.getString("log_in_time"));
			}
		}catch(Exception ex) {
			System.out.println("Error while extracting result from customer table " + ex.toString());
		}
		return customer;
	}
	private long getTimeFromDateTimeString(String dateTime) {
		SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
		try {
			return dateFormatter.parse(dateTime).getTime();
		}catch(Exception ex) {
			
		}
		return 0;
	}
}
