package db;

import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import system.ordering.cafe.DatabaseConnection;

public class OrdersTable {
	public static final String PENDING = "PENDING";
	public static final String NOT_CONFIRMED = "NOT_CONFIRMED";
	public static final String CONFIRMED = "CONFIRMED";
	
	private static final String TABLE_NAME = "orders";
	private DatabaseConnection dbConnect;
	private Statement stmnt;
	
	public int id;
	public int customerId;
	public int menuId;
	public int quantity;
	public long orderTime;
	public String orderStatus;
	
	public OrdersTable() {
		dbConnect = new DatabaseConnection();
		try {
			stmnt = dbConnect.getStatement();
		}catch(Exception ex) {
			System.out.println("Error in orders table class: " + ex.toString());
		}
	}
	
	public void addNewOrder(int customerId, int menuId, int quantity) {
		String query = "insert into " + TABLE_NAME 
				+ "(customer_id, menu_id,quantity) values(" 
				+ customerId + ","+menuId+","+quantity+");";
		try {
			System.out.println();
			stmnt.executeUpdate(query);
		}catch(Exception ex) {
			System.out.println("Error while inseting new entry into orders table " + ex.toString());
		}
	}
	public ArrayList<OrdersTable> getPendingOrders(int customerId){
		String query = "select * from " + TABLE_NAME + " where customer_id="
				+customerId+" and order_status='"+PENDING+"';";
		System.out.println(query);
		ArrayList<OrdersTable> orders = new ArrayList();
		try {
			ResultSet res = stmnt.executeQuery(query);
			while(res.next()) {
				OrdersTable obj = new OrdersTable();
				obj.id = res.getInt("id");
				obj.customerId = res.getInt("customer_id");
				obj.menuId = res.getInt("menu_id");
				obj.orderStatus = res.getString("order_status");
				obj.quantity = res.getInt("quantity");
				obj.orderTime = getTimeFromDateTimeString(res.getString("order_time"));
				orders.add(obj);
			}
		}catch(Exception ex) {
			System.out.println("Error while extracting pending orders " +  ex.toString());
		}
		return orders;
	}
	
	private long getTimeFromDateTimeString(String dateTime) {
		SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
		try {
			return dateFormatter.parse(dateTime).getTime();
		}catch(Exception ex) {
			
		}
		return 0;
	}
	public void updateOrderStatus(int id, String status) {
		String query = "update " + TABLE_NAME + " set order_status='"
				+status+"' where id="+id+";";
		System.out.println(query);
		try {
			stmnt.executeUpdate(query);
		}catch(Exception ex) {
			System.out.println("Error while udating order status " + ex.toString());
		}
	}
	
	public void updateOrderQunatity(int id, int quantity) {
		String query = "update " + TABLE_NAME + " set quantity="
				+quantity+" where id="+id+";";
		System.out.println(query);
		try {
			stmnt.executeUpdate(query);
		}catch(Exception ex) {
			System.out.println("Error while udating order status " + ex.toString());
		}
	}
	
	public OrdersTable getPendingOrder(int customerId, int menuId) {
		String query = "select * from " + TABLE_NAME + " where " 
				+ "customer_id="+customerId+" and menu_id="
				+ menuId+" and order_status='"+PENDING+"';";
		OrdersTable pendingOrder = new OrdersTable();
		try {
			ResultSet res = stmnt.executeQuery(query);
			pendingOrder = extractOrder(res);
		}catch(Exception ex) {
			System.out.println("Error while extracting pending orders " + ex.toString());
		}
		return pendingOrder;
	}
	private OrdersTable extractOrder(ResultSet res) {
		OrdersTable obj = new OrdersTable();
		try {
			while(res.next()) {
				obj.id = res.getInt("id");
				obj.customerId = res.getInt("customer_id");
				obj.menuId = res.getInt("menu_id");
				obj.orderStatus = res.getString("order_status");
				obj.quantity = res.getInt("quantity");
				obj.orderTime = getTimeFromDateTimeString(res.getString("order_time"));
			}
		}catch(Exception ex) {
			System.out.println("Error while extracting pending orders " + ex.toString());
		}
		return obj;
	}
}
