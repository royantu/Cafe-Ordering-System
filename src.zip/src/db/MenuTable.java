package db;

import java.sql.ResultSet;
import java.util.ArrayList;

import java.sql.Statement;

import system.ordering.cafe.DatabaseConnection;

public class MenuTable {
	private static final String TABLE_NAME = "menu";
	private DatabaseConnection dbConnect;
	private Statement stmnt;
	
	public int id;
	public String itemType;
	public String itemName;
	public int remaining;
	public int unitPrice;
	
	public MenuTable() {
		dbConnect = new DatabaseConnection();
		try {
			stmnt = dbConnect.getStatement();
		}catch(Exception ex) {
			System.out.println("Error in menu table class: " + ex.toString());
		}
	}
	
	public void updateRemainingValue(int id, int updatedValue) {
		String query = "update " + TABLE_NAME + " set remaining="+updatedValue
				+" where id="+id+";";
		System.out.println(query);
		try {
			stmnt.executeUpdate(query);
		}catch(Exception ex) {
			System.out.println("Error while updating menu table " + ex.toString());
		}
	}
	public String[] getDistinctItemType() {
		String query = "SELECT distinct(item_type) from " + TABLE_NAME+";";
		ArrayList<String> all = new ArrayList();
		try {
			ResultSet res = stmnt.executeQuery(query);
			while(res.next()) {
				all.add(res.getString("item_type"));
			}
		}catch(Exception ex) {
			System.out.println("Error " + ex.toString());
		}
		return all.toArray(new String[all.size()]);
	}
	
	public ArrayList<MenuTable> getDistinctItemName(String itemType) {
		String query = "SELECT * from " + TABLE_NAME+" where item_type='"+itemType+"';";
		ArrayList<MenuTable> all = new ArrayList();
		try {
			ResultSet res = stmnt.executeQuery(query);
			while(res.next()) {
				MenuTable obj = new MenuTable();
				obj.id = res.getInt("id");
				obj.itemType = res.getString("item_type");
				obj.itemName = res.getString("item_name");
				obj.remaining = res.getInt("remaining");
				obj.unitPrice = res.getInt("unit_price");
				all.add(obj);
			}
		}catch(Exception ex) {
			System.out.println("Error " + ex.toString());
		}
		return all;
	}
	public int getMenuTableId(String itemType, String itemName) {
		String query = "select id from " + TABLE_NAME 
				+ " where item_type='"+itemType+"' and item_name='"
				+itemName+"';";
		try {
			System.out.println(query);
			ResultSet res = stmnt.executeQuery(query);
			while(res.next())
				return res.getInt("id");
			
		}catch(Exception ex) {
			System.out.println("Error while retrieving id from menu table " + ex.toString());
		}
		return 0;
	}
	
	public MenuTable getMenuDetails(String itemType, String itemName) {
		String query = "select * from " + TABLE_NAME 
				+ " where item_type='"+itemType+"' and item_name='"
				+itemName+"';";
		MenuTable menuTable = new MenuTable();
		try {
			System.out.println(query);
			ResultSet res = stmnt.executeQuery(query);
			menuTable = extractMenuTable(res);
		}catch(Exception ex) {
			System.out.println("Error while retrieving id from menu table " + ex.toString());
		}
		return menuTable;
	}
	
	private MenuTable extractMenuTable(ResultSet res) {
		MenuTable obj = new MenuTable();
		try {
			while(res.next()) {
				obj.id = res.getInt("id");
				obj.itemType = res.getString("item_type");
				obj.itemName = res.getString("item_name");
				obj.remaining = res.getInt("remaining");
				obj.unitPrice = res.getInt("unit_price");
			}
		}catch(Exception ex) {
			System.out.println("Error while extracting menu table " + ex.toString());
		}
		return obj;
	}
	public MenuTable getMenu(int id) {
		String query = "select * from " + TABLE_NAME 
				+ " where id="+id+";";
		
		MenuTable menuTable = new MenuTable();
		try {
			System.out.println(query);
			ResultSet res = stmnt.executeQuery(query);
			menuTable = extractMenuTable(res);
		}catch(Exception ex) {
			System.out.println("Error while retrieving id from menu table " + ex.toString());
		}
		return menuTable;
	}
}
