package db;

import java.sql.Statement;

import system.ordering.cafe.DatabaseConnection;

public class LedgerTable {
	private static final String TABLE_NAME = "ledger";
	private DatabaseConnection dbConnect;
	private Statement stmnt;
	
	public int id;
	public int customerId;
	public int totalPrice;
	public String paymentStatus;
	
	public LedgerTable() {
		dbConnect = new DatabaseConnection();
		try {
			stmnt = dbConnect.getStatement();
		}catch(Exception ex) {
			System.out.println("Error in menu table class: " + ex.toString());
		}
	}
	
	public void addNewLedger(int customerId, int totalPrice) {
		String query = "insert into "+TABLE_NAME
				+"(customer_id,total_price) values("
				+customerId+","+totalPrice+");";
		System.out.println(query);
		try {
			stmnt.executeUpdate(query);
		}catch(Exception ex) {
			System.out.print("Error while inserting into eldger table "+ ex.toString());
		}
	}
}
