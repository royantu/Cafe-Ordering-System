package system.ordering.cafe;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;


public class DatabaseConnection{
	
	private static Connection con=null;
	private static final String DB_URL = "jdbc:mysql://localhost:3306/cafe_ordering_system";
	private static final String USER_NAME = "root";
	private static final String PASSWORD = "";
	
	public DatabaseConnection() {
		initConncetion();
	}
	
	private void initConncetion() {
		if(con!=null)
			return;
		try {
			if(con==null) {
				Class.forName("com.mysql.jdbc.Driver");
				con = DriverManager.getConnection(DB_URL,USER_NAME,PASSWORD);
				System.out.println("Connection Succedded");
			}
		}catch(Exception e){
			System.out.println("Error " + e.toString());
		}
	}
	public Statement getStatement() throws SQLException{
		return con.createStatement();
	}
	
}
