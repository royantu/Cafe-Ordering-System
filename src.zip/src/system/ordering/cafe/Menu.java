package system.ordering.cafe;

import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import db.MenuTable;
import db.OrdersTable;

public class Menu {
	private Integer customerId;
	private MenuTable menuTable;
	private OrdersTable ordersTable;
	
	private JFrame menuFrame;
	private JButton[] menuButtons;
	private JButton confirmOrderButton;
	private JButton closeButton;
	
	public Menu(Integer customerId) {
		this.customerId = customerId;
		menuTable = new MenuTable();
		ordersTable = new OrdersTable();
		initComponents();
	}
	
	private void initComponents() {
		menuFrame = new JFrame("Menu");
		confirmOrderButton = new JButton();
		closeButton = new JButton();
		
		String[] all = menuTable.getDistinctItemType();
		menuButtons = new JButton[all.length];
		for(int i=0;i<all.length;i++) {
			menuButtons[i] = new JButton(all[i]);
			menuButtons[i].setActionCommand(all[i]);
			menuButtons[i].setPreferredSize(new Dimension(50,15));
		}
		int row = Math.max(1,all.length/3);
		JPanel menuPanel = new JPanel();
		menuPanel.setPreferredSize(new  Dimension(50,25*menuButtons.length/2));
		GridLayout gl = new GridLayout(menuButtons.length/2,2,10,10);
		gl.setVgap(10);
		menuPanel.setLayout(gl);
		for(int i=0;i<menuButtons.length;i++) {
			menuPanel.add(menuButtons[i]);
		}
		
		JPanel orderPanel = new JPanel();
		confirmOrderButton.setText("Confirm order");
		confirmOrderButton.setPreferredSize(new Dimension(200,25));
		orderPanel.add(confirmOrderButton);
		
		closeButton.setText("Close");
		closeButton.setPreferredSize(new Dimension(100,25));
		orderPanel.add(closeButton);
		JLabel headingLabel = new JLabel("Select your menu");
		headingLabel.setFont(new Font(Font.SANS_SERIF, Font.ITALIC, 30));
		JPanel finalPanel = new JPanel();
		finalPanel.setLayout(new BoxLayout(finalPanel,BoxLayout.Y_AXIS));
		finalPanel.add(headingLabel);
		finalPanel.add(menuPanel);
		finalPanel.add(orderPanel);
		
		menuFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		menuFrame.setPreferredSize(new Dimension(500,500));
		menuFrame.add(finalPanel);
		//menuFrame.setLocationRelativeTo(null);
		menuFrame.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				updateMenuRemainingAndOrderStatusIfNotOrdered();
			}
		});
		menuFrame.pack();
		
		setActions();
	}
	
	private void setActions() {
		
		setMenuButtonsActions();
		setOrderButtonAction();
		setLogOutButtonAction();
	}
	
	private void setOrderButtonAction() {
		confirmOrderButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				ConfirmOrder confirmOrder = new ConfirmOrder(customerId);
				menuFrame.setVisible(false);
				confirmOrder.show();
			}
		});
	}
	
	private void setLogOutButtonAction() {
		closeButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				updateMenuRemainingAndOrderStatusIfNotOrdered();
				close();
			}

		});
	}
	
	public void close() {
		menuFrame.setVisible(false);
		menuFrame.dispose();
		CustomerLogin customerLogin = new CustomerLogin();
		customerLogin.show();
	}
	
	private void setMenuButtonsActions() {
		
		for(int i=0;i<menuButtons.length;i++) {
			menuButtons[i].addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
					processMenuButtonAction(e);
				}
			});
		}
	}
	
	private void processMenuButtonAction(ActionEvent e) {
		JButton button = (JButton) e.getSource();
		Order order = new Order(this.customerId, button.getText());
		menuFrame.setVisible(false);
		order.show();
		
	}
	
	public void show(){	
		menuFrame.setVisible(true);
	}
	
	public void setCustomerId(Integer id) {
		this.customerId = id;
	}
	
	public void updateMenuRemainingAndOrderStatusIfNotOrdered() {
		ArrayList<OrdersTable> pendingOrders = ordersTable.getPendingOrders(customerId);
		for(int i=0;i<pendingOrders.size();i++) {
			OrdersTable obj = pendingOrders.get(i);
			System.out.println("Current: " + obj.id);
			MenuTable menu = menuTable.getMenu(obj.menuId);
			menu.remaining += obj.quantity;
			menuTable.updateRemainingValue(menu.id, menu.remaining);
			ordersTable.updateOrderStatus(obj.id, OrdersTable.NOT_CONFIRMED);
		}
	}
}
