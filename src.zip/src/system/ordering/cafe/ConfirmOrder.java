package system.ordering.cafe;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import db.LedgerTable;
import db.MenuTable;
import db.OrdersTable;

public class ConfirmOrder {
	private JFrame confirmOrderJFrame;
	
	private MenuTable menuTable;
	private OrdersTable ordersTable;
	private Integer customerId;
	private LedgerTable ledgerTable;
	
	private JButton confirmButton;
	private JButton closeButton;
	
	private ArrayList<OrdersTable> pendingOrders;
	
	public ConfirmOrder(int customerId) {
		this.customerId = customerId;
		menuTable = new MenuTable();
		ordersTable = new OrdersTable();
		ledgerTable = new LedgerTable();
		
		initComponent();
	}
	
	private void initComponent() {
		confirmOrderJFrame = new JFrame();
		confirmOrderJFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		confirmOrderJFrame.setPreferredSize(new Dimension(500,500));
		//confirmOrderJFrame.setLocationRelativeTo(null);
		
		JPanel finalPanel = new JPanel();
		finalPanel.setLayout(new BoxLayout(finalPanel, BoxLayout.Y_AXIS));
		
		pendingOrders = ordersTable.getPendingOrders(customerId);
		int totalPrice = 0;
		JLabel heading = new JLabel();
		heading.setText("Summary of your orders");
		heading.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 30));
		finalPanel.add(heading);
		
		for(int i=0;i<pendingOrders.size();i++) {
			OrdersTable obj = pendingOrders.get(i);
			if(obj.quantity==0) continue;
			MenuTable menu = menuTable.getMenu(obj.menuId);
			
			JPanel linePanel = new JPanel();
			
			JLabel nameLabel = new JLabel();
			nameLabel.setText(menu.itemName+"");
			JLabel mathLabel = new JLabel();
			mathLabel.setText(obj.quantity+"x"+menu.unitPrice);
			JLabel priceLabel = new JLabel();
			priceLabel.setText((" = "+obj.quantity*menu.unitPrice+""));
			nameLabel.setFont(new Font(Font.SANS_SERIF, Font.ITALIC, 15));
			mathLabel.setFont(new Font(Font.SANS_SERIF, Font.ITALIC, 15));
			priceLabel.setFont(new Font(Font.SANS_SERIF, Font.ITALIC, 15));
			
			linePanel.add(nameLabel);
			linePanel.add(mathLabel);
			linePanel.add(priceLabel);
			
			totalPrice += obj.quantity*menu.unitPrice;
			finalPanel.add(linePanel);
		}
		JLabel totalLabel = new JLabel();
		totalLabel.setText("Total: " + totalPrice);
		totalLabel.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
		JPanel buttonPanel = new JPanel();
		confirmButton = new JButton();
		confirmButton.setText("Confirm");
		
		closeButton = new JButton();
		closeButton.setText("Close");
		
		buttonPanel.add(confirmButton);
		buttonPanel.add(closeButton);
		
		finalPanel.add(totalLabel);
		finalPanel.add(buttonPanel);
		
		finalPanel.setPreferredSize(new Dimension(300, 25 * (pendingOrders.size() + 3)));
		confirmOrderJFrame.add(finalPanel);
		confirmOrderJFrame.pack();
		confirmOrderJFrame.setVisible(false);
		confirmOrderJFrame.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				Menu menu = new Menu(customerId);
				menu.updateMenuRemainingAndOrderStatusIfNotOrdered();
			}
		});
		
		setActions();
	}
	
	private void setActions() {
		confirmButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				int totalPrice = 0;
				for(int i=0;i<pendingOrders.size();i++) {
					OrdersTable obj = pendingOrders.get(i);
					MenuTable menu = menuTable.getMenu(obj.menuId);
					totalPrice += obj.quantity * menu.unitPrice;
					ordersTable.updateOrderStatus(obj.id, OrdersTable.CONFIRMED);
				}
				ledgerTable.addNewLedger(customerId, totalPrice);
				JOptionPane.showMessageDialog(null, "Your order is confirmed!");
				gotoLoginPage();
			}
		});
		closeButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				close();
			}
		});
	}
	public void show() {
		confirmOrderJFrame.setVisible(true);
	}
	private void close() {
		confirmOrderJFrame.setVisible(false);
		confirmOrderJFrame.dispose();
		Menu menu = new Menu(customerId);
		menu.show();
	}
	private void gotoLoginPage() {
		confirmOrderJFrame.setVisible(false);
		confirmOrderJFrame.dispose();
		Menu menu = new Menu(customerId);
		menu.close();
	}
}
