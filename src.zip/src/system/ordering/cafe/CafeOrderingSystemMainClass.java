package system.ordering.cafe;

public class CafeOrderingSystemMainClass {

	public static void main(String[] args) {
		CustomerLogin obj = new CustomerLogin();
	}
}
