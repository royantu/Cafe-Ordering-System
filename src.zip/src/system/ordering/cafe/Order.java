package system.ordering.cafe;

import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.ArrayList;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import db.MenuTable;
import db.OrdersTable;

public class Order {
	private String itemType;
	private Integer customerId;
	private MenuTable menuTable;
	private OrdersTable ordersTable;
	
	private JFrame orderFrame;
	private JLabel[] itemNameLabel;
	private JTextField[] remainingTextField;
	private JComboBox[] orderComboBox;
	private JTextField[] unitPriceTextField;
	private JTextField[] totalPriceTextField;
	ArrayList<MenuTable> menuList;
	
	JButton orderButton;
	JButton closeButton;
	
	public Order(Integer customerId, String itemType) {
		menuTable = new MenuTable();
		ordersTable = new OrdersTable();
		this.customerId = customerId;
		this.itemType = itemType;
		menuList = new ArrayList();
		initComponents(customerId, itemType);
	}
	private void initComponents(int customerId, String itemType) {
		orderFrame = new JFrame("Select your item");
		orderButton = new JButton();
		closeButton = new JButton();
		menuList = menuTable.getDistinctItemName(itemType);
		
		itemNameLabel = new JLabel[menuList.size()];
		remainingTextField = new JTextField[menuList.size()];
		orderComboBox = new JComboBox[menuList.size()];
		unitPriceTextField = new JTextField[menuList.size()];
		totalPriceTextField = new JTextField[menuList.size()];
		
		
		for(int i=0;i<menuList.size();i++) {
			itemNameLabel[i] = new JLabel();
			
			remainingTextField[i] = new JTextField();
			remainingTextField[i].setEditable(false);
			
			orderComboBox[i] = new JComboBox();
			
			unitPriceTextField[i] = new JTextField();
			unitPriceTextField[i].setEditable(false);
			
			totalPriceTextField[i] = new JTextField();
			totalPriceTextField[i].setEditable(false);
		}
		
		
		JPanel namePanel = new JPanel();
		namePanel.setLayout(new BoxLayout(namePanel, BoxLayout.Y_AXIS));
		
		JPanel remainingPanel = new JPanel();
		remainingPanel.setLayout(new BoxLayout(remainingPanel, BoxLayout.Y_AXIS));
		
		JPanel orderPanel = new JPanel();
		orderPanel.setLayout(new BoxLayout(orderPanel, BoxLayout.Y_AXIS));
		
		JPanel unitPricePanel = new JPanel();
		unitPricePanel.setLayout(new BoxLayout(unitPricePanel, BoxLayout.Y_AXIS));
		
		JPanel totalPricePanel = new JPanel();
		totalPricePanel.setLayout(new BoxLayout(totalPricePanel, BoxLayout.Y_AXIS));
		
		JLabel nameLabel = new JLabel("Item Name");
		JLabel remainingLabel = new JLabel("Remaining");
		JLabel orderLabel = new JLabel("Select");
		JLabel unitPriceLabel = new JLabel("Unit price");
		JLabel totalPriceLabel = new JLabel("Total Price");
		
		namePanel.add(nameLabel);
		remainingPanel.add(remainingLabel);
		orderPanel.add(orderLabel);
		unitPricePanel.add(unitPriceLabel);
		totalPricePanel.add(totalPriceLabel);
		
		for(int i=0;i<menuList.size();i++) {
			MenuTable menu = menuList.get(i);
			OrdersTable pendingOrder = ordersTable.getPendingOrder(customerId, menu.id);
			itemNameLabel[i].setText(menu.itemName);
			remainingTextField[i].setText(menu.remaining+"");
			for(int j=0;j<=menu.remaining + pendingOrder.quantity;j++)
				orderComboBox[i].addItem(j);
			orderComboBox[i].setSelectedItem(pendingOrder.quantity);
			unitPriceTextField[i].setText(menu.unitPrice+"");
			totalPriceTextField[i].setText((menu.unitPrice * pendingOrder.quantity)+"");
			
			namePanel.add(itemNameLabel[i]);
			remainingPanel.add(remainingTextField[i]);
			orderPanel.add(orderComboBox[i]);
			unitPricePanel.add(unitPriceTextField[i]);
			totalPricePanel.add(totalPriceTextField[i]);
			
		}
		
		JPanel buttonPanel = new JPanel();
		orderButton.setText("Order");
		orderButton.setPreferredSize(new Dimension(100,25));
		closeButton.setText("Close");
		closeButton.setPreferredSize(new Dimension(100,25));
		buttonPanel.add(orderButton);
		buttonPanel.add(closeButton);
		
		JPanel menuPanel = new JPanel();
		menuPanel.add(namePanel);
		menuPanel.add(remainingPanel);
		menuPanel.add(orderPanel);
		menuPanel.add(unitPricePanel);
		menuPanel.add(totalPricePanel);
		
		JPanel finalPanel = new JPanel();
		finalPanel.setLayout(new BoxLayout(finalPanel, BoxLayout.Y_AXIS));
		finalPanel.add(menuPanel);
		finalPanel.add(buttonPanel);
		
		orderFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		orderFrame.setPreferredSize(new Dimension(500,500));
		//orderFrame.setLocationRelativeTo(null);
		orderFrame.add(finalPanel);
		orderFrame.pack();
		
		setActions();
	}
	
	public void show() {
		orderFrame.setVisible(true);
	}
	private void setActions() {
		setButtonActions();
		setComboBoxAction();
	}
	private void setButtonActions() {
		orderButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				for(int i=0;i<orderComboBox.length;i++) {
					int quantity = Integer.parseInt(orderComboBox[i].getSelectedItem().toString());
					MenuTable menuDetails = menuTable.getMenuDetails(itemType, itemNameLabel[i].getText());
					OrdersTable orders = ordersTable.getPendingOrder(customerId, menuDetails.id);
					System.out.println("Here " + menuDetails.remaining + " " + orders.quantity);
					menuDetails.remaining += orders.quantity;
					if(orders.quantity==0) {
						if(quantity==0) continue;
						ordersTable.addNewOrder(customerId, menuDetails.id, quantity);
					}
					else
						ordersTable.updateOrderQunatity(orders.id, quantity);
					menuDetails.remaining -= quantity;
					menuTable.updateRemainingValue(menuDetails.id,menuDetails.remaining);
				}
				JOptionPane.showMessageDialog(null, "Order of "+itemType.toLowerCase()+" is recorded!");
				close();
			}
			
		});
		
		closeButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				close();
			}
		});
	}
	
	private void close() {
		orderFrame.setVisible(false);
		orderFrame.dispose();
		Menu menu = new Menu(customerId);
		menu.show();
	}
	
	private void setComboBoxAction() {
		for(int i=0;i<orderComboBox.length;i++) {
			processComboBoxAction(orderComboBox[i],i);
		}
	}
	
	private void processComboBoxAction(JComboBox cb, int index) {
		cb.addItemListener(new ItemListener() {
			@Override
			public void itemStateChanged(ItemEvent ie) {
				int selected = Integer.parseInt(ie.getItem().toString());
				int remaining = menuList.get(index).remaining;
				int unitPrice = menuList.get(index).unitPrice;
				OrdersTable orders = ordersTable.getPendingOrder(customerId, menuList.get(index).id); 
				remainingTextField[index].setText((remaining-selected+orders.quantity)+"");
				totalPriceTextField[index].setText((unitPrice*selected)+"");
			}
			
		});
	}
}
