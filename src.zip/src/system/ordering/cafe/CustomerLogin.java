package system.ordering.cafe;

import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import db.CustomerTable;

public class CustomerLogin {
	private CustomerTable customerTable;
	
	private static final int WIDTH = 500;
	private static final int LENGTH = 500;
	
	private static final int TEXT_FIELD_LENGTH = 200;
	
	private JFrame customerLoginFrame;
	private JTextField nameTextField;
	private JTextField mobileNumberTextField;
	private JTextField tableNumberTextField;
	
	private JButton itemButton;
	private JButton exitButton;
	
	public CustomerLogin() {
		customerTable = new CustomerTable();
		initComponents();
	}
	
	private void initComponents() {
		customerLoginFrame = new JFrame();
		nameTextField = new JTextField();
		mobileNumberTextField = new JTextField();
		tableNumberTextField = new JTextField();
		itemButton = new JButton();
		exitButton = new JButton();
		
		customerLoginFrame.setName("Customer Login");
		customerLoginFrame.setPreferredSize(new Dimension(WIDTH, LENGTH));
		customerLoginFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JLabel headingLabel = new JLabel("Customer Login");
		headingLabel.setFont(new Font(Font.SANS_SERIF, Font.ITALIC, 40));
		
		JLabel nameLabel = new JLabel("Name");
		nameLabel.setFont(new Font(Font.SANS_SERIF,Font.BOLD, 25));
		nameTextField.setPreferredSize(new Dimension(200, 25));
		
		JLabel mobileNumberLabel = new JLabel("Mobile Number");
		mobileNumberLabel.setFont(new Font(Font.SANS_SERIF,Font.BOLD, 25));
		mobileNumberTextField.setPreferredSize(new Dimension(TEXT_FIELD_LENGTH, 25));
		

		JLabel tableNumberLabel = new JLabel("Table Number");
		tableNumberLabel.setFont(new Font(Font.SANS_SERIF,Font.BOLD, 25));
		tableNumberTextField.setPreferredSize(new Dimension(TEXT_FIELD_LENGTH, 25));
		
		itemButton.setPreferredSize(new Dimension(100,35));
		itemButton.setText("Items");
		
		exitButton.setPreferredSize(new Dimension(100,35));
		exitButton.setText("Exit");
		
		JPanel headingPanel = new JPanel();
		headingPanel.add(headingLabel);
		
		JPanel namePanel = new JPanel();
		namePanel.add(nameLabel);
		namePanel.add(nameTextField);
		
		JPanel mobileNumberPanel = new JPanel();
		mobileNumberPanel.add(mobileNumberLabel);
		mobileNumberPanel.add(mobileNumberTextField);
		
		JPanel tableNumberPanel = new JPanel();
		tableNumberPanel.add(tableNumberLabel);
		tableNumberPanel.add(tableNumberTextField);
		
		JPanel buttonPanel = new JPanel();
		buttonPanel.add(itemButton);
		buttonPanel.add(exitButton);
		
		JPanel finalPanel = new JPanel();
		finalPanel.setLayout(new BoxLayout(finalPanel, BoxLayout.PAGE_AXIS));
		finalPanel.add(headingPanel);
		finalPanel.add(namePanel);
		finalPanel.add(mobileNumberPanel);
		finalPanel.add(tableNumberPanel);
		finalPanel.add(buttonPanel);
		customerLoginFrame.add(finalPanel);
		customerLoginFrame.pack();
		//customerLoginFrame.setLocationRelativeTo(null);
		customerLoginFrame.setVisible(true);
		
		setActions();
	}
	
	private void setActions() {
		itemButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				String name = nameTextField.getText();
				String mobileNumber = mobileNumberTextField.getText();
				String tableNumber = tableNumberTextField.getText();
				if(name==null || name.length()==0)
					JOptionPane.showMessageDialog(null, "Name can not be empty",
							"Error", JOptionPane.ERROR_MESSAGE);
				
				else if(mobileNumber==null || mobileNumber.length()==0)
					JOptionPane.showMessageDialog(null, "Mobile number can not be empty",
							"Error", JOptionPane.ERROR_MESSAGE);
				
				else if(tableNumber==null || tableNumber.length()==0)
					JOptionPane.showMessageDialog(null, "Table number can not be empty",
							"Error", JOptionPane.ERROR_MESSAGE);
				else {
					customerTable.addNewCustomer(name, mobileNumber, tableNumber);
					CustomerTable customer = customerTable.getLatesEntry(mobileNumber);
					customerLoginFrame.setVisible(false);
					Menu menu = new Menu(customer.id);
					menu.show();
				}
			}
			
		});
		exitButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				customerLoginFrame.setVisible(false);
				customerLoginFrame.dispose();
			}
		});
	}
	public void show() {
		customerLoginFrame.setVisible(true);
	}
}