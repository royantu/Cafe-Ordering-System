package exception;

public class CustomerIdIsNotSetException extends CafeOrderingSystemException{

	public CustomerIdIsNotSetException() {
		this("Invalid customer id");
	}
	
	public CustomerIdIsNotSetException(String message) {
		super(message);
	}
	
}
