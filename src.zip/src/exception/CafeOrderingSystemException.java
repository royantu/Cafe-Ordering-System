package exception;

public class CafeOrderingSystemException extends Exception{
	public CafeOrderingSystemException(String message) {
		super(message);
	}
}
